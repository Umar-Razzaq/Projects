#include <iostream>
using namespace std;
template <class S>
class my_vector
{
private:
	S *arr;
	int cap;
	int count;
public:
	my_vector();
	~my_vector();
	void push_back(S temp);
	void pop_back();
	void remove(S temp);
	S operator [](int index);
	void print();
};

template <class S>
void my_vector<S>::print()
{
    if(arr==NULL)
    {
        cout<<"Boi is empty\n";
    }
    else
    {
        for(int x=0;x<count;x++)
        {
            cout<<arr[x]<<"  ";
        }
    }
}
template <class S>
S my_vector<S>::operator[](int index)
{
	if(index<0 || index>count-1)
	{
		cout<<"index out of bounds\n";
		S temp;
		return temp;
	}
	else
		return arr[index];
}
template <class S>
my_vector<S>::my_vector()
{
	arr=NULL;
	cap=0;
	count=0;
}

template <class S>
my_vector<S>::~my_vector()
{
	if(arr!=NULL)
	{
		delete [] arr;
	}
}
template <class S>
void my_vector<S>::push_back(S temp)
{
	if(arr==NULL)
	{
		arr=new S[10];
		arr[0]=temp;
		count++;
		cap=10;
	}
	else
	{
		if(count==cap)
		{
			S *temp=new S[cap+10];
			for(int x=0;x<count;x++)
			{
				temp[x]=arr[x];
			}
			cap=cap+10;
			arr=temp;
		}
		arr[count]=temp;
		count++;
	}
}
template<class S>
void my_vector<S>::pop_back()
{
	if(arr==NULL)
	{
		cout<<"Its already empty"<<endl;
	}
	else
	{
		count--;
		if(count==0)
            arr=NULL;
	}

}
template<class S>
void my_vector<S>::remove(S temp)
{
	if(arr==NULL)
	{
		cout<<"Its already empty"<<endl;
		return;
	}
	else
	{
		for(int x=0; x<count; x++)
		{
			if(arr[x]==temp)
			{
				for(int y=x; y<count-1; y++)
				{
					arr[y]= arr[y+1];
				}
				count--;
				x--;
			}
		}
	}
	if(count==0)
        arr=NULL;
}

int main()
{
	my_vector<char> Boi;
	int choice;
	do
    {
        cout<<"1. Push back\n";
        cout<<"2. Pop back\n";
        cout<<"3. Remove a boi\n";
        cout<<"4. Value at an index\n";
        cout<<"5. Print\n";
        cout<<"-1. to exit\n";
        cout<<"Enter your choice: ";
        cin>>choice;

        if(choice==1)
        {
            cout<<"Enter the new boi: ";
            char new_boi;
            cin>>new_boi;
            Boi.push_back(new_boi);
        }
        else if(choice==2)
        {
            Boi.pop_back();
        }
        else if(choice==3)
        {
            cout<<"Enter the boi you want to remove: ";
            char new_boi;
            cin>>new_boi;
            Boi.remove(new_boi);
        }
        else if(choice==4)
        {
            cout<<"Enter the index: ";
            int new_boi;
            cin>>new_boi;
            cout<<"Boi at the given index is: "<<Boi[new_boi];
        }
        else if(choice==5)
        {
            Boi.print();
        }
        else if(choice==-1)
        {
            cout<<"\t\tBYE\n\n";
        }
        cout<<endl<<endl;

	}while(choice!=-1);

	return 0;
}
